/* File: metering.c
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */

#include "metering.h"
#include "stm8l15x_flash.h"

const float Aperture_Half_Stop[MAX_Aperture_Count] = {1,1.2,1.4,1.7,2,2.4,2.8,3.3,3.5,4,4.8,5.6,6.7,8,9.5,11,13,16,19,22,27,32,38,45,54,64};
const float ISO[MAX_ISO_Count] = {25, 50, 100, 160, 200, 250, 320, 400, 500, 800, 1600, 3200};
const float ShutterSpeed[MAX_ShutterSpeed_Count] = {1000, 500, 250, 125, 60, 30, 15, 8, 4, 2, 1};
const float EV_Bias[MAX_EvBias_Count] = {-1.0,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0};

struct CurrentStates_st states;

void Meter_Init(void)
{
	states.UI = UI_ISO;
	states.OutOfRange = FALSE;
	
	states.PriorityMode = (Priority_Mode_TypeDef)FLASH_ReadByte(EEPROM_PRIORITY_ADDR);
	if(states.PriorityMode != S_Priority && states.PriorityMode != A_Priority)
		states.PriorityMode = A_Priority;
	
	states.ISOIndex = FLASH_ReadByte(EEPROM_ISO_ADDR);
	if(states.ISOIndex > MAX_ISO_Count-1)
		states.ISOIndex = DEFAULT_ISO_INDEX;
		
	states.EvBiasIndex = FLASH_ReadByte(EEPROM_EVBIAS_ADDR);
	if(states.EvBiasIndex > MAX_EvBias_Count-1)
		states.EvBiasIndex = DEFAULT_EV_INDEX;

	states.ShutterSpeedIndex = DEFAULT_S_INDEX;
	states.ApertureIndex = DEFAULT_A_INDEX;
	states.Lux = 0;
	states.Fstop = 0;
	states.SS = 0;
}

float Meter_GetLux()
{
	u16 regValue;
	double lux, lux_calibrated;
	
	VEML_I2C_PowerOn(I2C1, VEML7700_GAIN_1_4, VEML7700_IT_100MS); //resolution = 0.2304
  delay_ms(150);
  VEML_I2C_Read(I2C1, VEML7700_ALS_DATA, &regValue);
  VEML_I2C_ShutDown(I2C1);
	lux = regValue * 0.2304f;
	
	if(lux < 24) //0.2304*100 = 23.04
	{
		VEML_I2C_PowerOn(I2C1, VEML7700_GAIN_2, VEML7700_IT_100MS);
		delay_ms(150);
		VEML_I2C_Read(I2C1, VEML7700_ALS_DATA, &regValue);
		VEML_I2C_ShutDown(I2C1);
		lux_calibrated = regValue * 0.0288f;
	}
  else if(lux > 900) // 0.2304*4000=921.6
    lux_calibrated = 6.0135E-13*pow(lux,4) - 9.2924E-9*pow(lux,3) + 8.1488E-5*pow(lux,2) + 1.0023E0*pow(lux, 1);
  else
    lux_calibrated = lux;
  
  return lux_calibrated;
}

float Meter_GetLux_1_4Gain_100ms()
{
  u16 regValue;
	double lux, lux_calibrated; //lux_VEML
  const double resolution = 0.2304; //Gain 1/4, ITime 100ms, Max lux 15099 raw, 32979 calibrated
  
  VEML_I2C_PowerOn(I2C1, VEML7700_GAIN_1_4, VEML7700_IT_100MS);
  delay_ms(200);
  VEML_I2C_Read(I2C1, VEML7700_ALS_DATA, &regValue);
  VEML_I2C_ShutDown(I2C1);
  
  
  lux = regValue * resolution;
  if(regValue > 4000) // 0.2304*4000=921.6
    lux_calibrated = 6.0135E-13*pow(lux,4) - 9.2924E-9*pow(lux,3) + 8.1488E-5*pow(lux,2) + 1.0023E0*pow(lux, 1);
  else
    lux_calibrated = lux;
  
  return lux_calibrated;
}

float Meter_CalAperture(double lux, float ISO, float ShutterSpeed)
{ 
	float pow_2_ev = lux/_correctFactor*ISO/K;
	float f_value = sqrt(pow_2_ev * pow(2, -EV_Bias[states.EvBiasIndex]) / ShutterSpeed);
  
	/* python script
	>>> import math
	>>> f=[1, 1.2, 1.4, 1.7, 2, 2.4, 2.8, 3.3, 4, 4.8, 5.6, 6.7, 8, 9.5, 11, 13, 16, 19, 22]
	>>> for i in range(len(f)):
		print(f[i]*pow(2,1/8))
	
		
	1.0905077326652577
	1.3086092791983093
	1.5267108257313606
	1.853863145530938
	2.1810154653305154
	2.6172185583966185
	3.0534216514627213
	3.59867551779535
	4.362030930661031
	5.234437116793237
	6.1068433029254425
	7.306401808857227
	8.724061861322062
	10.359823460319948
	11.995585059317834
	14.17660052464835
	17.448123722644123
	20.719646920639896
	23.99117011863567
	*/
  
	states.OutOfRange = FALSE;
  if(f_value<0.9170)
  {
    f_value = 0;
		states.OutOfRange = TRUE;
	}
  else if(f_value>=0.9170 && f_value<=1.0905) //<=f*2^(1/8)
    f_value = 1;
  else if(f_value>1.0905 && f_value<=1.3086)
    f_value = 1.2;
  else if(f_value>1.3086 && f_value<=1.5267)
    f_value = 1.4;
  else if(f_value>1.5267 && f_value<=1.8539)
    f_value = 1.7;
  else if(f_value>1.8539 && f_value<=2.1810)
    f_value = 2;
  else if(f_value>2.1810 && f_value<=2.6172)
    f_value = 2.4;
  else if(f_value>2.6172 && f_value<=3.0534)
    f_value = 2.8;
  else if(f_value>3.0534 && f_value<=3.5987)
    f_value = 3.3;
  else if(f_value>3.5987 && f_value<=4.3620)
    f_value = 4;
  else if(f_value>4.3620 && f_value<=5.2344)
    f_value = 4.8;
  else if(f_value>5.2344 && f_value<=6.1068)
    f_value = 5.6;
  else if(f_value>6.1068 && f_value<=7.3064)
    f_value = 6.7;
  else if(f_value>7.3064 && f_value<=8.7241)
    f_value = 8;
  else if(f_value>8.7241 && f_value<=10.3598)
    f_value = 9.5;
  else if(f_value>10.3598 && f_value<=11.9956)
    f_value = 11;
  else if(f_value>11.9956 && f_value<=14.1766)
    f_value = 13;
  else if(f_value>14.1766 && f_value<=17.4481)
    f_value = 16;
  else if(f_value>17.4481 && f_value<=20.7196)
    f_value = 19;
  else if(f_value>20.7196 && f_value<=23.9912)
    f_value = 22;
  else
	{
    f_value = 0;
		states.OutOfRange = TRUE;
	}
	
  return f_value;
}

float Meter_CalShutterSpeed(double lux, float ISO, float Aperture)
{
	float pow_2_ev = lux/_correctFactor*ISO/K;
	float ss_value = pow_2_ev * pow(2, -EV_Bias[states.EvBiasIndex]) / pow(Aperture, 2);
  
	/* python script
	>>> ss = [0.5,1,2,3,4,6,8,10,15,20,30,45,60,90,125,180,250,350,500,750,1000,1500]
	>>> for i in range(len(ss)-1):
			print(2/(1/ss[i]+1/ss[i+1]))
	
			
	0.6666666666666666
	1.3333333333333333
	2.4000000000000004
	3.428571428571429
	4.800000000000001
	6.857142857142858
	8.88888888888889
	11.999999999999998
	17.142857142857142
	23.999999999999996
	36.0
	51.42857142857143
	72.0
	104.65116279069767
	147.54098360655738
	209.30232558139534
	291.6666666666667
	411.764705882353
	600.0
	857.1428571428572
	1200.0
	*/
	
	states.OutOfRange = FALSE;
  if(ss_value<0.6667)
  {
    ss_value = 0;
		states.OutOfRange = TRUE;
	}
  else if(ss_value>=0.6667 && ss_value<=1.3333)
    ss_value = 1;
  else if(ss_value>1.3333 && ss_value<=2.4000)
    ss_value = 2;
  else if(ss_value>2.4000 && ss_value<=3.4286)
    ss_value = 3;
  else if(ss_value>3.4286 && ss_value<=4.8000)
    ss_value = 4;
  else if(ss_value>4.8000 && ss_value<=6.8571)
    ss_value = 6;
  else if(ss_value>6.8571 && ss_value<=8.8889)
    ss_value = 8;
  else if(ss_value>8.8889 && ss_value<=12.0000)
    ss_value = 10;
  else if(ss_value>12.0000 && ss_value<=17.1429)
    ss_value = 15;
  else if(ss_value>17.1429 && ss_value<=24.0000)
    ss_value = 20;
  else if(ss_value>24.0000 && ss_value<=36.0000)
    ss_value = 30;
  else if(ss_value>36.0000 && ss_value<=51.4286)
    ss_value = 45;
  else if(ss_value>51.4286 && ss_value<=72.0000)
    ss_value = 60;
  else if(ss_value>72.0000 && ss_value<=104.6512)
    ss_value = 90;
  else if(ss_value>104.6512 && ss_value<=147.5410)
    ss_value = 125;
  else if(ss_value>147.5410 && ss_value<=209.3023)
    ss_value = 180;
  else if(ss_value>209.3023 && ss_value<=291.6667)
    ss_value = 250;
  else if(ss_value>291.6667 && ss_value<=411.7647)
    ss_value = 350;
  else if(ss_value>411.7647 && ss_value<=600.0000)
    ss_value = 500;
  else if(ss_value>600.0000 && ss_value<=857.1429)
    ss_value = 750;
  else if(ss_value>857.1429 && ss_value<=1200.0000)
    ss_value = 1000;
  else
  {
    ss_value = 0;
		states.OutOfRange = TRUE;
	}
  
  return ss_value;
}