#include "VEML7700.h"

void VEML_I2C_Write(I2C_TypeDef* I2Cx, uint16_t RegisterAddr, uint16_t* data)
{
  while(I2C_GetFlagStatus(I2Cx,I2C_FLAG_BUSY));
  
  I2C_GenerateSTART(I2Cx,ENABLE);                                            //Start    
  while(!I2C_CheckEvent(I2Cx,I2C_EVENT_MASTER_MODE_SELECT));

  I2C_Send7bitAddress(I2Cx, VEML7700_I2CADDR<<1, I2C_Direction_Transmitter); //Slave addr
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));  //Tx mode
  
  I2C_SendData(I2Cx, (uint8_t)(RegisterAddr & 0x00FF));                      //Send Reg addr LSB
  while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTING));
  //I2C_SendData(I2Cx, (uint8_t)((RegisterAddr & 0xFF00)>>8));                 //Send Reg addr MSB
  //while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTING));           //Datasheet error?
  
  I2C_SendData(I2Cx, (uint8_t)(*data & 0x00FF));
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTING));
  I2C_SendData(I2Cx, (uint8_t)((*data & 0xFF00)>>8));
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
  
  I2C_GenerateSTOP(I2Cx,ENABLE);                                             //Stop
}

void VEML_I2C_Read(I2C_TypeDef* I2Cx, uint16_t RegisterAddr, uint16_t* data)
{
	uint8_t dataLSB, dataMSB;
	
  while(I2C_GetFlagStatus(I2Cx,I2C_FLAG_BUSY));
  
  I2C_GenerateSTART(I2Cx,ENABLE);                                            //Start    
  while(!I2C_CheckEvent(I2Cx,I2C_EVENT_MASTER_MODE_SELECT));
  
  I2C_Send7bitAddress(I2Cx, VEML7700_I2CADDR<<1, I2C_Direction_Transmitter); //Slave addr
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));  //Tx mode
  
  I2C_SendData(I2Cx, (uint8_t)(RegisterAddr & 0x00FF));                      //Send Reg addr LSB
  while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTING));
  //I2C_SendData(I2Cx, (uint8_t)((RegisterAddr & 0xFF00)>>8));                 //Send Reg addr MSB
  //while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTING));           //Datasheet error?
  
  I2C_GenerateSTART(I2Cx,ENABLE);                                            //Start
  while(!I2C_CheckEvent(I2Cx,I2C_EVENT_MASTER_MODE_SELECT));
  
  I2C_Send7bitAddress(I2Cx, VEML7700_I2CADDR<<1, I2C_Direction_Receiver);    //Slave addr
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));     //Rx mode
  
  while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED));             //Read data LSB
  dataLSB = I2C_ReceiveData(I2Cx);
  I2C_AcknowledgeConfig(I2Cx,ENABLE);
  while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED));             //Read data MSB
  dataMSB = I2C_ReceiveData(I2Cx); 
  I2C_AcknowledgeConfig(I2Cx, DISABLE);  
  I2C_GenerateSTOP(I2Cx,ENABLE);                                             //Stop
  
  I2C_AcknowledgeConfig(I2Cx, ENABLE);
  
  *data = (uint16_t)dataLSB | ((uint16_t)dataMSB)<<8;
}

void VEML_I2C_PowerOn(I2C_TypeDef* I2Cx, VEML_GAIN_TypeDef Gain, VEML_IT_TypeDef ITime)
{
  u16 readout = 0x0000;
  //VEML_I2C_Read(I2Cx, VEML7700_ALS_CONFIG, &readout);
  //readout = (readout & ~VEML7700_SHUTDOWN_MASK) | VEML7700_ALS_POWERON;
  readout = VEML7700_ALS_POWERON | (u16)Gain | (u16)ITime;
  VEML_I2C_Write(I2Cx, VEML7700_ALS_CONFIG, &readout);
}

void VEML_I2C_ShutDown(I2C_TypeDef* I2Cx)
{
  u16 readout;
  VEML_I2C_Read(I2Cx, VEML7700_ALS_CONFIG, &readout);
  readout = (readout & ~VEML7700_SHUTDOWN_MASK) | VEML7700_ALS_SHUTDOWN;
  VEML_I2C_Write(I2Cx, VEML7700_ALS_CONFIG, &readout);
}

void VEML_I2C_SetSensitivity(I2C_TypeDef* I2Cx, VEML_GAIN_TypeDef Gain, VEML_IT_TypeDef ITime)
{
  u16 readout;
  VEML_I2C_Read(I2Cx, VEML7700_ALS_CONFIG, &readout);
  readout = (readout & ~VEML7700_GAIN_MASK) | (u16)Gain;
  readout = (readout & ~VEML7700_IT_MASK) | (u16)ITime;
  VEML_I2C_Write(I2Cx, VEML7700_ALS_CONFIG, &readout);
}
