/* File: GDC04520_lcd.h
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */

#ifndef __GDC04520_LCD_H__
#define __GDC04520_LCD_H__

#include "stm8l15x.h"
#include "stm8l15x_clk.h"
#include "stm8l15x_lcd.h"

/* Define for character '.' */
#define  POINT_OFF FALSE
#define  POINT_ON TRUE

void LCD_GLASS_Init(void);
void LCD_GLASS_WriteChar(uint8_t* ch, bool point, uint8_t position);
void LCD_GLASS_DisplayString(uint8_t* ptr);
void LCD_GLASS_DisplayStrDeci(uint16_t* ptr);
void LCD_GLASS_Clear(void);

#endif