/* File: VEML7700_H.h
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */
	
#ifndef __VEML7700_H
 #define __VEML7700_H

#include "stm8l15x_i2c.h"
#include "delay.h"
/* Device Address */
#define VEML7700_I2CADDR 0x10 ///< I2C address

/* Register Address */
#define VEML7700_ALS_CONFIG          0x0000  ///< Light configuration register
#define VEML7700_ALS_THREHOLD_HIGH   0x0001  ///< Light high threshold for irq
#define VEML7700_ALS_THREHOLD_LOW    0x0002  ///< Light low threshold for irq
#define VEML7700_ALS_POWER_SAVE      0x0003  ///< Power save regiester
#define VEML7700_ALS_DATA            0x0004  ///< The light data output
#define VEML7700_WHITE_DATA          0x0005  ///< The white light data output
#define VEML7700_INTERRUPTSTATUS     0x0006  ///< What IRQ (if any)

/* Register Mask */
#define VEML7700_GAIN_MASK           0x1800 //Bit 12:11
#define VEML7700_IT_MASK             0x03C0 //Bit 9:6
#define VEML7700_PERS_MASK           0x0030 //Bit 5:4
#define VEML7700_INT_EN_MASK         0x0002 //Bit 1
#define VEML7700_SHUTDOWN_MASK       0x0001 //Bit 0

#define VEML7700_PSM_MASK            0x0006 //Bit 2:1
#define VEML7700_PSM_EN_MASK         0x0001 //Bit 0

#define VEML7700_INT_LOW_MASK        0x8000 //Bit 15
#define VEML7700_INT_HIGH_MASK       0x4000 //Bit 14

/* Register Value */
typedef enum {
  VEML7700_GAIN_1_8 = 0x1000,
  VEML7700_GAIN_1_4 = 0x1800,
  VEML7700_GAIN_1   = 0x0000,
  VEML7700_GAIN_2   = 0x0800
} VEML_GAIN_TypeDef;

typedef enum {
  VEML7700_IT_25MS = 0x0300,
  VEML7700_IT_50MS = 0x0200,
  VEML7700_IT_100MS = 0x0000,
  VEML7700_IT_200MS = 0x0040,
  VEML7700_IT_400MS = 0x0080,
  VEML7700_IT_800MS = 0x00C0
} VEML_IT_TypeDef;

/*
#define VEML7700_GAIN_1              0x0000  ///< ALS gain 1x
#define VEML7700_GAIN_2              0x0800  ///< ALS gain 2x
#define VEML7700_GAIN_1_8            0x1000  ///< ALS gain 1/8x
#define VEML7700_GAIN_1_4            0x1800  ///< ALS gain 1/4x
#define VEML7700_IT_100MS            0x0000  ///< ALS intetgration time 100ms
#define VEML7700_IT_200MS            0x0040  ///< ALS intetgration time 200ms
#define VEML7700_IT_400MS            0x0080  ///< ALS intetgration time 400ms
#define VEML7700_IT_800MS            0x00C0  ///< ALS intetgration time 800ms
#define VEML7700_IT_50MS             0x0200  ///< ALS intetgration time 50ms
#define VEML7700_IT_25MS             0x0300  ///< ALS intetgration time 25ms
*/
#define VEML7700_PERS_1              0x0000  ///< ALS irq persisance 1 sample
#define VEML7700_PERS_2              0x0010  ///< ALS irq persisance 2 samples
#define VEML7700_PERS_4              0x0020  ///< ALS irq persisance 4 samples
#define VEML7700_PERS_8              0x0030  ///< ALS irq persisance 8 samples
#define VEML7700_ALS_POWERON         0x0000 ///< ALS power on
#define VEML7700_ALS_SHUTDOWN        0x0001 ///< ALS shut down

#define VEML7700_PSM_DISABLE         0x0000
#define VEML7700_PSM_ENABLE          0x0001
#define VEML7700_POWERSAVE_MODE1     0x0000  ///< Power saving mode 1
#define VEML7700_POWERSAVE_MODE2     0x0002  ///< Power saving mode 2
#define VEML7700_POWERSAVE_MODE3     0x0004 ///< Power saving mode 3
#define VEML7700_POWERSAVE_MODE4     0x0006  ///< Power saving mode 4


#define VEML7700_INTERRUPT_HIGH      0x4000 ///< Interrupt status for high threshold
#define VEML7700_INTERRUPT_LOW       0x8000 ///< Interrupt status for low threshold

void VEML_I2C_Write(I2C_TypeDef* I2Cx, uint16_t RegisterAddr, uint16_t* data);
void VEML_I2C_Read(I2C_TypeDef* I2Cx, uint16_t RegisterAddr, uint16_t* data);
void VEML_I2C_PowerOn(I2C_TypeDef* I2Cx, VEML_GAIN_TypeDef Gain, VEML_IT_TypeDef ITime);
void VEML_I2C_ShutDown(I2C_TypeDef* I2Cx);
void VEML_I2C_SetSensitivity(I2C_TypeDef* I2Cx, VEML_GAIN_TypeDef Gain, VEML_IT_TypeDef ITime);

#endif
