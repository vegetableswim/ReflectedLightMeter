/* File: metering.h
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */
 
#ifndef __METERING_H
#define __METERING_H

#include "math.h"
#include "VEML7700.h"

typedef enum {
  UI_Meter = 0x00,
  UI_ISO,
  UI_PriorityMode
} UI_State_TypeDef;

typedef enum {
  A_Priority = 0x00,
  S_Priority
} Priority_Mode_TypeDef;

// Default ISO and Priority Mode Memory Address
#define EEPROM_ISO_ADDR       (u32)(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS+0)
#define EEPROM_PRIORITY_ADDR  (u32)(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS+1)
#define EEPROM_EVBIAS_ADDR    (u32)(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS+2)

// Parameters
#define MAX_Aperture_Count 26
#define MAX_ISO_Count 12
#define MAX_ShutterSpeed_Count 11
#define MAX_EvBias_Count 21
#define DEFAULT_ISO_INDEX 4 // ISO200
#define DEFAULT_A_INDEX 13  // f8
#define DEFAULT_S_INDEX 3   // 1/125s
#define DEFAULT_EV_INDEX 12  // +- 0ev

extern const float Aperture_Half_Stop[MAX_Aperture_Count];
extern const float ISO[MAX_ISO_Count];
extern const float ShutterSpeed[MAX_ShutterSpeed_Count];
extern const float EV_Bias[MAX_EvBias_Count];

// Current states
struct CurrentStates_st {
	UI_State_TypeDef      UI;
	Priority_Mode_TypeDef PriorityMode;
	bool                  OutOfRange;
	u8                    ISOIndex;
	u8                    ShutterSpeedIndex;
	u8                    ApertureIndex;
	u8										EvBiasIndex;
	double                Lux;
	float                 Fstop;
	float                 SS;
};

extern struct CurrentStates_st states;

// Metering variables and functions
#define _correctFactor (float)0.451899f //bigger then more exposure, previous 0.38
#define K 12.5f

void Meter_Init(void);
float Meter_GetLux(void);
float Meter_GetLux_1_4Gain_100ms(void);
float Meter_CalAperture(double lux, float ISO, float ShutterSpeed);
float Meter_CalShutterSpeed(double lux, float ISO, float Aperture);

#endif
