/* File: display.c
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */
	
#include "display.h"

void Display_Init(void)
{
	LCD_GLASS_Init();
}

void Display_Clear(void)
{
	LCD_GLASS_Clear();
}

void Display_ALS(uint16_t als)
{
  u16 div = 10000; //u16 max 65535
  u8 c;
  bool findFirstNonZero = FALSE;
	u8 i = 0;
	
	LCD_GLASS_Clear();
  for(i=0; i<5; i++)
  {
    c = (als/div) + '0';
    als = als % div;
    div /=10;
    
    if(!findFirstNonZero)
    {
      if(c == '0')
        c = ' ';
      else
        findFirstNonZero = TRUE;
    }
    /*
    if(c != '0')
      findFirstNonZero = TRUE;
    if(c == '0' && !findFirstNonZero)
      c = ' ';
    */  
    LCD_GLASS_WriteChar(&c, POINT_OFF, 4-i);

  }
}

/*| b.c.| */
void Display_BatteryCheck()
{
  u8 c;
	
	LCD_GLASS_Clear();
	
  c = 'b';
  LCD_GLASS_WriteChar(&c, POINT_ON, 3);
  c = 'c';
  LCD_GLASS_WriteChar(&c, POINT_ON, 2);
  
  LCD_BlinkConfig(LCD_BlinkMode_AllSEG_AllCOM, LCD_BlinkFrequency_Div512);
}

/*|- 200-| */
void Display_ISO(float iso)
{
  u8 c, i;
	u16 tmp = (u16)iso;
	u16 div = 1000;
	bool findFirstNonZero = FALSE;

	LCD_GLASS_Clear();
	
	for(i=0; i<4; i++)
	{
		c = tmp/div + '0';
		tmp = tmp % div;
		div /= 10;

		if(!findFirstNonZero)
		{
			if(c == '0')
				c = ' ';
			else
				findFirstNonZero = TRUE;
		}
		LCD_GLASS_WriteChar(&c, POINT_OFF, 4-i);
	}

  c = '-';
  LCD_GLASS_WriteChar(&c, POINT_OFF, 5);
  LCD_GLASS_WriteChar(&c, POINT_OFF, 0);
}

void Display_EvBias(float bias)
{
	u8 c, tmp, div;
	u8 i = 0;
	
	LCD_GLASS_Clear();
	c = '[';
	LCD_GLASS_WriteChar(&c, POINT_OFF, 5);
	c = ']';
	LCD_GLASS_WriteChar(&c, POINT_OFF, 0);
	LCD_GLASS_WriteChar(&c, POINT_ON, 3);
	if(bias < 0)
	{
		bias = -bias;
		c = '-';
		LCD_GLASS_WriteChar(&c, POINT_OFF, 4);
	}
	tmp = (u8)((bias+0.001f)*100);// plus 0.01 to avoid float rounding issue(6.7->6.699999) in Cosmic

	div = 100;
	for(i=0; i<3; i++)
	{
		c = tmp/div + '0';
		tmp = tmp % div;
		div /= 10;
		if(i==0)
			LCD_GLASS_WriteChar(&c, POINT_ON, 3-i);
		else
		LCD_GLASS_WriteChar(&c, POINT_OFF, 3-i);
	}
}

/* |  -A.- | 
 * |  -S.- |
 */
void Display_PriorityMode(bool aperture_priority)
{
  u8 c, c1;
	
	LCD_GLASS_Clear();
  if(aperture_priority)
    c = 'A';
  else
    c = 'S';
  
  LCD_GLASS_WriteChar(&c, POINT_ON, 2);
  
  c1 = '-';
  LCD_GLASS_WriteChar(&c1, POINT_OFF, 1);
  LCD_GLASS_WriteChar(&c1, POINT_OFF, 3);
}

/* |5.61000| 
 * |125  8|
 */
void Display_MeterResult(float f, float ss, bool out_of_range, bool aperture_priority)
{
  u8 c;
  u16 tmp = (u16)ss;
	u16 div = 1000;
	bool findFirstNonZero = FALSE;
	u8 i = 0;
	
  if(!aperture_priority) //SS Priority
  {
    // Display Aperture
    if(out_of_range)
    {
      c = 'o';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 5);
      c = 'r';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 4);
    }
    else if(f<10)
    {
      u8 tmp = (u8)((f+0.01f)*10); // plus 0.01 to avoid float rounding issue(6.7->6.699999) in Cosmic
      c = tmp/10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_ON, 5);
      c = tmp%10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 4);
    }else
    {
      c = (u8)f/10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 5);
      c = (u8)f%10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 4);
    }
    
    // Display ShutterSpeed
    for(i=0; i<4; i++)
    {
      c = tmp/div + '0';
      tmp = tmp % div;
      div /= 10;

      if(!findFirstNonZero)
      {
        if(c == '0')
          c = ' ';
        else
          findFirstNonZero = TRUE;
      }
      LCD_GLASS_WriteChar(&c, POINT_OFF, 3-i);
    }
  }
  else //Aperture Priority
  {
    LCD_GLASS_Clear();
    
    // Display ShutterSpeed
    if(out_of_range)
    {
      c = 'o';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 5);
      c = 'r';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 4);
    }
    else
    {
      u16 tmp = (u16)ss;
      u16 div = 1000;
      bool findFirstNonZero = FALSE;
      u8 startPosition;
      if(tmp<1000)
        startPosition = 6;
      else
        startPosition = 5;
      
      for(i=0; i<4; i++)
      {
        c = tmp/div + '0';
        tmp = tmp % div;
        div /= 10;

        if(!findFirstNonZero)
        {
          if(c == '0')
            c = ' ';
          else
            findFirstNonZero = TRUE;
        }
        LCD_GLASS_WriteChar(&c, POINT_OFF, startPosition-i);
      }
    }
		
		// Display Fstop
    if(f<10)
    {
      u8 tmp = (u8)((f+0.01f)*10); // plus 0.01 to avoid float rounding issue(6.7->6.699999) in Cosmic
      c = tmp/10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_ON, 1);
      c = tmp%10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 0);
    }else
    {
      c = (u8)f/10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 1);
      c = (u8)f%10 + '0';
      LCD_GLASS_WriteChar(&c, POINT_OFF, 0);
    }
  }
}
	