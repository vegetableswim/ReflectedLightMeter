/* File: GDC04520_lcd.c
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */

#include "GDC04520_lcd.h"

/*  =========================================================================
                                 LCD MAPPING
    =========================================================================
 6 Character, 4COM * 12SEG
   
 Position5  ..  Position4  ......  Position0
   --A--
   |   |
  F|   |B
   --G--
   |   |
  E|   |C
   --D--  DP 

 An LCD character coding is based on the following matrix:
           COM0  COM1  COM2  COM3
 SEG(n)   { B,    G,    C,    DP}
 SEG(n+1) { A,    F,    E,    D}

 In STM8L152Kx LQFP32 Package
 n = {8, 10, 12, 14, 16, 18}



 -------------------
 Using a uint8 var to describe from COM3 to COM0, MSB to LSB:
       D, P, E, C, F, G, A, B
 "0" = 1, 0, 1, 1, 1, 0, 1, 1 = 0xBB;  

*/

/* code for 'A' character */
#define C_AMap 0x3F

/* code for 'b' character */
#define C_bMap 0xBC

/* code for 'c' character */
#define C_cMap 0xA4

/* code for 'o' character */
#define C_oMap 0xB4

/* code for 'r' character */
#define C_rMap 0x24

/* code for 'S' character */
#define C_SMap 0X9E

/* code for '-' character */
#define C_minusMap 0x04

/* code for '[' character */
#define C_leftBracketMap 0xAA

/* code for ']' character */
#define C_rightBracketMap 0x93

/* code for space */
#define C_spaceMap 0x00

/* code for Dot/DP */
#define C_dotMap 0x40

/* Constant table for number '0' --> '9' */
const uint16_t NumberMap[10]=
    {
        /* 0      1      2      3      4      5      6      7      8      9  */
           0XB4,  0X11,  0XA7,  0X97,  0X1D,  0X9E,  0XBE,  0X13,  0XBF,  0X9F
    };

static void LCD_Conv_Char_Seg(uint8_t* c, bool point, uint8_t* digit);

/**
  * @brief  Configures the LCD GLASS relative GPIO port IOs and LCD peripheral.
  * @param  None
  * @retval None
  */
void LCD_GLASS_Init(void)
{
	
 /* Enable LCD/RTC clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_RTC, ENABLE);
  CLK_PeripheralClockConfig(CLK_Peripheral_LCD, ENABLE);
  
  #ifdef USE_LSE
    CLK_RTCClockConfig(CLK_RTCCLKSource_LSE, CLK_RTCCLKDiv_1);
  #else
    CLK_RTCClockConfig(CLK_RTCCLKSource_LSI, CLK_RTCCLKDiv_1);
  #endif
  
  /* Initialize the LCD */
  LCD_Init(LCD_Prescaler_1, LCD_Divider_31, LCD_Duty_1_4, 
           LCD_Bias_1_3, LCD_VoltageSource_External);
    
  /* Mask register
  For declare the segements used.
  In STM8L152Kx LQFP32 Package, we use 8 to 19 segments. */
  LCD_PortMaskConfig(LCD_PortMaskRegister_1, 0xFF); //SEG8~15
  LCD_PortMaskConfig(LCD_PortMaskRegister_2, 0x0F); //SEG16~19
  
  /* Contrast control */
  LCD_DeadTimeConfig(LCD_DeadTime_1); //Battery Power 3V
  LCD_PulseOnDurationConfig(LCD_PulseOnDuration_2);
  
  /* Enable LCD peripheral */ 
  LCD_Cmd(ENABLE);
}

static void LCD_Conv_Char_Seg(uint8_t* c,bool point, uint8_t* digit)
{
  uint8_t ch = 0;
  uint8_t i;
  switch (*c)
  {
    case ' ':
      ch = C_spaceMap;
      break;
    case 'A':
      ch = C_AMap;
      break;
    case 'b':
      ch = C_bMap;
      break;
    case 'c':
      ch = C_cMap;
      break;
    case 'o':
      ch = C_oMap;
      break;
    case 'r':
      ch = C_rMap;
      break;
    case 'S':
      ch = C_SMap;
      break;
    case '-':
      ch = C_minusMap;
      break;
    case '[':
      ch = C_leftBracketMap;
      break;
    case ']':
      ch = C_rightBracketMap;
      break;
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
      ch = NumberMap[*c-0x30];
      break;
      
    default:
      break;
  }
  
  if (point) ch |= C_dotMap;
  
  for(i=0; i<4; i++)
  {
    digit[i] = (ch >> 2*i) & 0x03; //Split into 4 *2bit and order by(1,0, 3,2, 5,4, 7,6)
  }
}

void LCD_GLASS_WriteChar(uint8_t* ch, bool point, uint8_t position)
{
  uint8_t digit[4];
  LCD_Conv_Char_Seg(ch, point, digit);
  
  LCD->CR3 &= 0xf7; //Clear bit3 SOFC
  while((LCD->CR3 & 0x10) != 0x10); //if bit4 SOF is set
  
  switch (position)
  {
    case 0: //SEG8,9
      LCD->RAM[LCD_RAMRegister_1] &= 0xfc; // 1A 1B
      LCD->RAM[LCD_RAMRegister_1] |= digit[0];
      
      LCD->RAM[LCD_RAMRegister_4] &= 0xcf; // 1F 1G
      LCD->RAM[LCD_RAMRegister_4] |= digit[1]<<4;
      
      LCD->RAM[LCD_RAMRegister_8] &= 0xfc; // 1E 1C
      LCD->RAM[LCD_RAMRegister_8] |= digit[2];
      
      LCD->RAM[LCD_RAMRegister_11] &= 0xcf; //1D 1P
      LCD->RAM[LCD_RAMRegister_11] |= digit[3]<<4;
      break;
      
    case 1: //SEG10, 11
      LCD->RAM[LCD_RAMRegister_1] &= 0xf3;
      LCD->RAM[LCD_RAMRegister_1] |= digit[0]<<2;
      
      LCD->RAM[LCD_RAMRegister_4] &= 0x3f;
      LCD->RAM[LCD_RAMRegister_4] |= digit[1]<<6;
      
      LCD->RAM[LCD_RAMRegister_8] &= 0xf3;
      LCD->RAM[LCD_RAMRegister_8] |= digit[2]<<2;
      
      LCD->RAM[LCD_RAMRegister_11] &= 0x3f;
      LCD->RAM[LCD_RAMRegister_11] |= digit[3]<<6;
      break;
      
    case 2: //SEG12, 13
      LCD->RAM[LCD_RAMRegister_1] &= 0xcf;
      LCD->RAM[LCD_RAMRegister_1] |= digit[0]<<4;
      
      LCD->RAM[LCD_RAMRegister_5] &= 0xfc;
      LCD->RAM[LCD_RAMRegister_5] |= digit[1];
      
      LCD->RAM[LCD_RAMRegister_8] &= 0xcf;
      LCD->RAM[LCD_RAMRegister_8] |= digit[2]<<4;
      
      LCD->RAM[LCD_RAMRegister_12] &= 0xfc;
      LCD->RAM[LCD_RAMRegister_12] |= digit[3];
      break;
      
    case 3: //SEG14, 15
      LCD->RAM[LCD_RAMRegister_1] &= 0x3f;
      LCD->RAM[LCD_RAMRegister_1] |= digit[0]<<6;
      
      LCD->RAM[LCD_RAMRegister_5] &= 0xf3;
      LCD->RAM[LCD_RAMRegister_5] |= digit[1]<<2;
      
      LCD->RAM[LCD_RAMRegister_8] &= 0x3f;
      LCD->RAM[LCD_RAMRegister_8] |= digit[2]<<6;
      
      LCD->RAM[LCD_RAMRegister_12] &= 0xf3;
      LCD->RAM[LCD_RAMRegister_12] |= digit[3]<<2;
      break;
      
    case 4: //SEG16, 17
      LCD->RAM[LCD_RAMRegister_2] &= 0xfc;
      LCD->RAM[LCD_RAMRegister_2] |= digit[0];
      
      LCD->RAM[LCD_RAMRegister_5] &= 0xcf;
      LCD->RAM[LCD_RAMRegister_5] |= digit[1]<<4;
      
      LCD->RAM[LCD_RAMRegister_9] &= 0xfc;
      LCD->RAM[LCD_RAMRegister_9] |= digit[2];
      
      LCD->RAM[LCD_RAMRegister_12] &= 0xcf;
      LCD->RAM[LCD_RAMRegister_12] |= digit[3]<<4;
      break;
      
    case 5: //SEG18, 19
      LCD->RAM[LCD_RAMRegister_2] &= 0xf3;
      LCD->RAM[LCD_RAMRegister_2] |= digit[0]<<2;
      
      LCD->RAM[LCD_RAMRegister_5] &= 0x3f;
      LCD->RAM[LCD_RAMRegister_5] |= digit[1]<<6;
      
      LCD->RAM[LCD_RAMRegister_9] &= 0xf3;
      LCD->RAM[LCD_RAMRegister_9] |= digit[2]<<2;
      
      LCD->RAM[LCD_RAMRegister_12] &= 0x3f;
      LCD->RAM[LCD_RAMRegister_12] |= digit[3]<<6;
      break;
 
    default:
      break;
  }
  
}

void LCD_GLASS_Clear(void)
{
  uint8_t counter = 0;
  
  for (counter = 0; counter <= LCD_RAMRegister_13; counter++)
  {
    LCD->RAM[counter] = LCD_RAM_RESET_VALUE;
  }
}
