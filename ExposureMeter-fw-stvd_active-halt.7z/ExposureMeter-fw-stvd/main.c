/**
  ******************************************************************************
  * @file    Project/STM8L15x_StdPeriph_Template/main.c
  * @author  MCD Application Team
  * @version V1.6.1
  * @date    30-September-2014
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm8l15x.h"
#include "stm8l15x_gpio.h"
#include "stm8l15x_exti.h"
#include "stm8l15x_i2c.h"
#include "stm8l15x_itc.h"
#include "stm8l15x_pwr.h"
#include "stm8l15x_flash.h"

#include "metering.h"
#include "display.h"

/** @addtogroup STM8L15x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
bool BatteryLow = FALSE;
/* Private function prototypes -----------------------------------------------*/
static void CLK_Config(void);
static void GPIO_Config(void);
static void I2C_Config(void);
void RefreshMeter(void);
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void main(void)
{
	disableInterrupts();
	CLK_Config();
  GPIO_Config();
  I2C_Config();
	Meter_Init();
	Display_Init();
	
	//Check battery level
  PWR_DeInit();
  PWR_PVDLevelConfig(PWR_PVDLevel_2V65);
	//PWR_PVDITConfig(ENABLE);
  PWR_PVDCmd(ENABLE);
  delay_ms(100);
  if(PWR_GetFlagStatus(PWR_FLAG_PVDOF) == SET)
  {
    Display_BatteryCheck();
    BatteryLow = TRUE;
  }
  PWR_PVDCmd(DISABLE);
	
	if(!BatteryLow)
	{
		// Set EV bias
		if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_6) == RESET) //Top button
		{
			LCD_BlinkConfig(LCD_BlinkMode_AllSEG_AllCOM, LCD_BlinkFrequency_Div512);
			Display_EvBias(EV_Bias[states.EvBiasIndex]);
			delay_ms(2000);
			while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_6) != RESET)
			{
				if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_4) == RESET && states.EvBiasIndex < MAX_EvBias_Count-1) //Forward
					states.EvBiasIndex += 1;
				else if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_2) == RESET && states.EvBiasIndex > 0) //Backward
					states.EvBiasIndex -= 1;
					
				Display_EvBias(EV_Bias[states.EvBiasIndex]);
				delay_ms(180);
			}
			//Save to EEPROM
			if(FLASH_ReadByte(EEPROM_EVBIAS_ADDR) != states.EvBiasIndex)
			{
				FLASH_DeInit();
				FLASH_Unlock(FLASH_MemType_Data);
				FLASH_EraseByte(EEPROM_EVBIAS_ADDR);
				FLASH_ProgramByte(EEPROM_EVBIAS_ADDR, states.EvBiasIndex);
				FLASH_Lock(FLASH_MemType_Data);
			}
			LCD_BlinkConfig(LCD_BlinkMode_Off, LCD_BlinkFrequency_Div512);
		}
		
		// Show ISO setting
		Display_ISO(ISO[states.ISOIndex]);
		delay_ms(2000);
		Display_Clear();
		
		// Show EV bias
		Display_EvBias(EV_Bias[states.EvBiasIndex]);
		delay_ms(1000);
		
		// First metering
		states.UI = UI_Meter;
		states.Lux = Meter_GetLux();
		RefreshMeter();
	}
	
	/**
    * RM0031 Page74/82
    * 74 CPU to return to WFI mode without restoring the main execution context.
		* 82 Setting this bit causes the CPU to return to Halt mode 
		*    when executing the return from interrupt, without restoring the main execution context.
    */
  CFG->GCR &= CFG_GCR_AL;
	
	/**
	 * RM0031 Page68 internal voltage reference
	 * PWR_CSR2_ULP: Disable Vrefint in Active/Halt mode:BOR/PVD/ADC/VLCD
	 * PWR_CSR2_FWU: Fast wakeup withou wait Vrefint startup time 3ms
	 */
	PWR_UltraLowPowerCmd(ENABLE); //For Active-Halt mode
	
	
	EXTI_ClearITPendingBit(EXTI_IT_Pin2);
	EXTI_ClearITPendingBit(EXTI_IT_Pin3);
	EXTI_ClearITPendingBit(EXTI_IT_Pin4);
	EXTI_ClearITPendingBit(EXTI_IT_Pin6);
	PWR_PVDClearITPendingBit();
  enableInterrupts();
	
  /* Infinite loop */
  while (1)
  {
		//wfi();
		halt();
  }
}

static void CLK_Config(void)
{
  CLK_HSICmd(ENABLE);
  CLK_SYSCLKSourceConfig(CLK_SYSCLKSource_HSI);
  CLK_SYSCLKDivConfig(CLK_SYSCLKDiv_16); //Default HSI 16MHz / 16 = 1MHz
  while (CLK_GetSYSCLKSource() != CLK_SYSCLKSource_HSI);
}

static void GPIO_Config(void)
{
  GPIO_Init(GPIOC, GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4, GPIO_Mode_In_PU_IT); //Backward, Push, Forward
  GPIO_Init(GPIOD, GPIO_Pin_6, GPIO_Mode_In_PU_IT); //Top button
  
  // Set unused Pins output low
  GPIO_Init(GPIOA, GPIO_Pin_2|GPIO_Pin_3, GPIO_Mode_Out_PP_Low_Slow);
  GPIO_Init(GPIOC, GPIO_Pin_5|GPIO_Pin_6, GPIO_Mode_Out_PP_Low_Slow);
  GPIO_Init(GPIOD, GPIO_Pin_7, GPIO_Mode_Out_PP_Low_Slow);
  GPIO_ResetBits(GPIOA, GPIO_Pin_2|GPIO_Pin_3);
  GPIO_ResetBits(GPIOC, GPIO_Pin_5|GPIO_Pin_6);
  GPIO_ResetBits(GPIOD, GPIO_Pin_7);
  
  EXTI_SetPinSensitivity(EXTI_Pin_2, EXTI_Trigger_Falling);
  EXTI_SetPinSensitivity(EXTI_Pin_3, EXTI_Trigger_Falling);
  EXTI_SetPinSensitivity(EXTI_Pin_4, EXTI_Trigger_Falling);
  EXTI_SetPinSensitivity(EXTI_Pin_6, EXTI_Trigger_Falling);
  
  ITC_SetSoftwarePriority(EXTI2_IRQn, ITC_PriorityLevel_2);
  ITC_SetSoftwarePriority(EXTI3_IRQn, ITC_PriorityLevel_2);
  ITC_SetSoftwarePriority(EXTI4_IRQn, ITC_PriorityLevel_2);
  ITC_SetSoftwarePriority(EXTI6_IRQn, ITC_PriorityLevel_2);
}

static void I2C_Config(void)
{
  GPIO_Init(GPIOC, GPIO_Pin_0|GPIO_Pin_1, GPIO_Mode_Out_OD_HiZ_Slow);
  CLK_PeripheralClockConfig(CLK_Peripheral_I2C1, ENABLE);
  I2C_Init(I2C1, 100000, 0x00, I2C_Mode_I2C, I2C_DutyCycle_2,
           I2C_Ack_Enable, I2C_AcknowledgedAddress_7bit);
}

void RefreshMeter()
{
	if(states.PriorityMode == A_Priority)
	{
		states.SS = Meter_CalShutterSpeed(states.Lux, ISO[states.ISOIndex], Aperture_Half_Stop[states.ApertureIndex]);
		Display_MeterResult(Aperture_Half_Stop[states.ApertureIndex], 
												states.SS, 
												states.OutOfRange, 
												states.PriorityMode == A_Priority);
		
	}
	else
	{
		states.Fstop = Meter_CalAperture(states.Lux, ISO[states.ISOIndex], ShutterSpeed[states.ShutterSpeedIndex]);
		Display_MeterResult(states.Fstop, 
												ShutterSpeed[states.ShutterSpeedIndex], 
												states.OutOfRange, 
												states.PriorityMode == A_Priority);																			
	}
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
