/* File: display.h
 *
 * Author: vegetableswim
 *
 * Change Logs:
 * Date        Note
 * 2019-08-14  the first version
 */
	
#ifndef __DISPLAY_H
#define __DISPLAY_H

#include "GDC04520_lcd.h"

void Display_Init(void);
void Display_Clear(void);
void Display_ALS(uint16_t als);
void Display_BatteryCheck(void);
void Display_ISO(float iso);
void Display_EvBias(float bias);
void Display_PriorityMode(bool aperture_priority);
void Display_MeterResult(float f, float ss, bool out_of_range, bool aperture_priority);

#endif
