#include "delay.h"

void delay_ms(u16 n_ms)
{
  /* Init TIMER 4 */
  CLK_PeripheralClockConfig(CLK_Peripheral_TIM4, ENABLE);
  /* HSI div by 16 --> Auto-Reload value: 1MHz / Prescaler 4 = 1/4MHz, 1/4MHz / 1kHz = 250*/ 
  TIM4_TimeBaseInit(TIM4_Prescaler_4,250);
  TIM4_SetCounter(0);
  TIM4_ClearFlag(TIM4_FLAG_Update);
  TIM4_Cmd(ENABLE);
  while(n_ms--)
  {
    while(TIM4_GetFlagStatus(TIM4_FLAG_Update) == 0) ;
    TIM4_ClearFlag(TIM4_FLAG_Update);
  }
  TIM4_Cmd(DISABLE);
}